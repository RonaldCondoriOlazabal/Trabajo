package pe.edu.upeu.sysalmacenfx.control;

import org.springframework.stereotype.Component;

@Component
public class ProductoController {
}
